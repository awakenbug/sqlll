
<h1 align="center">
  <img src="https://i.ibb.co/LYnKqpr/logopsqli.png"></h1>
   <h3 align="center">Fast Automatic Sql injection, SQLi Dumper<br>URL Fuzzer, Dork Tools & cracking tools
<p align="center">
  </a>
  <a href="https://github.com/Agressiv1njector/psqli">
     <img src="https://i.ibb.co/br5DH3z/1586858881-picsay.jpg" height="30" width="210">
  </a>
</h3>
</p>
<p align="center">
  <img src="https://i.ibb.co/JjGDcgw/psqli2.png">
</p>

### Fitur

- singgle site injection
- Mass Xploit sql-injection
- aUTO DorKiNg + AutO Xploit
- SQLi Base64 injection
- SQLi POST method
- SQLi ERROR Based method
- Scan site + auto inject ( web crawler )
- Reverse ip vuln sqli + auto inject
- Query Email Pass dumper + auto filter mail
- Hash tools
- Dork generator
- New Admin Finder
- Psqli Sqli/Xss/LFI/AdminFinder Scanner

### Methode injection

#### psqli mempunyai 2 metode inject

- Union based method
- Error based method

#### Di lengkapi

- auto detect vuln
- order by bisa di sesuaikan
- auto detect string based
- new bypassing waf query
- multiple injection method
- auto filtering table
- auto correct input db dan table
- local variabel method
- tertanam 6 dios racikan master sqli
- auto filter email::password
- auto scaning dorking
- skip prosess dengan ctrl+c atau ctrl+d
- query bisa di edit sesuai selera
- html injection
- base64 injection
- double query injection
- post method injection
- mencari login page dengan 2 method
- fast URL scraping atau crawler
- auto dorking edit lahh bagian .sites dan .key untuk mendapatkan hasil yang memuaskan
- mudahh edit input output di bagian atas script
- Dan masih banyak lagi

### Fix error inject site
- https://www.prettypetalsstore.com/single.php?id=68
- https://www.smkdarulmuqomah.id/statis-16-program-keahlian.html
- https://www.sedimental.com/catalog/index.php?ID=80
- http://sekarlaut.com/products.php?ID=23&cID=1
- http://lexsite.com/latestArticle.php?id=5
- http://gandariacity.co.id/tenant.php?id=17
- http://tf.lan.go.id/statis-1-profil.html
- http://www.godmother.co.uk/single-blog.php?blog_id=66

### Instalasi
```bash
$ apt-get install bash curl git
$ git clone https://github.com/Agressiv1njector/psqli
$ cd psqli
$ bash psqli.sh
$ bash psqli.sh s #untuk string based injection only
```
**psqli* is licensed under [GPL v3.0 license](https://www.gnu.org/licenses/gpl-3.0.en.html)


